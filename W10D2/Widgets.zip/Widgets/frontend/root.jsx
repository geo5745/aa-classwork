import React from 'react';
import ReactDOM from 'react-dom';
import Clock from './clock.jsx';
import Tab from './tab.jsx';
import Autocomplete from './autocomplete.jsx';

class Root extends React.Component{
    constructor(props){
        super(props);
    }
    render(){
        return(
            <>
                <Clock />
                <Tab />
                <Autocomplete names = {this.props.names} />
            </>
        );
    }
}
export default Root;