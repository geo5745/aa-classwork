import {partyHeader} from "./warmup";
import {htmlGenerator} from "./warmup";
// import warmUp from "./warmup.js"; // DOES NOT WORK. WHY?
import clock from "./clock.js";


//htmlGenerator('Party Time.', partyHeader);

//const clockDiv = document.getElementById('clock');
//htmlGenerator('Party Time.', clockDiv);


// warmUp.htmlGenerator('Party Time.', partyHeader);
// individual import works, but importing the entire page doesn't. WHY?

